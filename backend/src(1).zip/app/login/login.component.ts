import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  username: string;
  password: string;
  loginObj: any;
  isSuccessful = false;
  isSignUpFailed = false;
  errorMessage = '';
  constructor(private router: Router,) {
    this.loginObj = {
      username:'',
      password:''
    };
  }

  ngOnInit(): void {
  }

  login() {
    if (this.loginObj.username == 'admin' && this.loginObj.password == '1234') {
      this.router.navigateByUrl('/admin');
  }
  else if (this.loginObj.password == '') {
    alert('Password required');
  }
  else if (this.loginObj.username == '') {
    alert('Username required');
  }
  else {
    console.log(this.loginObj.username, this.loginObj.password);
    alert('wrong information');
  }
  }


}
