import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  username: string;
  password: string;
  loginObj: any;
  isSuccessful = false;
  isSignUpFailed = false;
  errorMessage = '';
  constructor(private router: Router,) {
    this.loginObj = {
      email:'',
      username:'',
      password:'',
      passconf:'',

    };
  }

  ngOnInit(): void {
  }

  login() {
    if (this.loginObj.password == '') {
    alert('Password required');
  } else if (this.loginObj.password !== this.loginObj.passconf) {
    alert('password not matching');
  }
  else if (this.loginObj.username == '') {
    alert('Username required');
  } 
  else if (this.loginObj.email == '') {
    alert('email required');
  }
  else {
    this.router.navigateByUrl('/admin');
  }
  } 


}
